# 🎵 Luis García — Descargador de Música Aleatoria del Mundo

Aplicación web lista para subir a internet que permite descubrir, escuchar y descargar música aleatoria de todo el mundo **100% gratis** (Creative Commons y Dominio Público vía Internet Archive).

## ✨ Características
- 🌍 **Música de todo el planeta**: Todo el Mundo, Latinoamérica, Europa, Asia, África, Norteamérica, Medio Oriente y Caribe.
- 🎶 **Filtros por género**: Electrónica, Jazz, Folk, Rock/Indie, Clásica, Lo-Fi/Ambient, Reggae/Dub y Latina.
- ▶️ **Reproductor integrado** con disco animado, visualizador de barras, control de tiempo y volumen.
- ⬇️ **Descarga directa en MP3** con un solo clic y sin registros.
- ❤️ **Favoritos e Historial** guardados automáticamente en tu navegador.
- 🎨 **Diseño moderno y colorido** adaptable a celulares, tablets y computadoras.

## 🚀 Cómo ejecutar en tu computadora
```bash
npm install
npm start
```
Luego abre `http://localhost:3000` en tu navegador.

## ☁️ Cómo subirla gratis a Internet (Render.com)
1. Sube esta carpeta (`luis-garcia-music`) a un repositorio en **GitHub**.
2. Crea una cuenta gratis en [render.com](https://render.com).
3. Haz clic en **New + → Web Service** y conecta tu repositorio.
4. Render detectará `render.yaml` automáticamente (`npm install` y `npm start`).
5. ¡Listo! En 1 minuto tendrás tu sitio **Luis García** en línea funcionando en cualquier navegador.
